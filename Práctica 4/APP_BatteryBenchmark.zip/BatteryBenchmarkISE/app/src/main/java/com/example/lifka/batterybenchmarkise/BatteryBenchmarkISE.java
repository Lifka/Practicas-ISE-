package com.example.lifka.batterybenchmarkise;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.Calendar;

public class BatteryBenchmarkISE extends AppCompatActivity {


    TextView nivelactual;
    ImageView start;
    TextView niveltext;
    TextView nivel_result;
    TextView temperatura_nivel;
    TextView voltaje_act;
    TextView estado_bat;
    TextView time_result;
    TextView bateria_var;
    private float actual = -1;
    private float temperatura = -1;
    private float voltaje = -1;
    private int estado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery_benchmark_ise);


        init();

        nivelactual.setText("  " + Float.toString(actual) + " %");
        temperatura_nivel.setText("  " + temperatura + " ºC");
        voltaje_act.setText(" " + voltaje +  " V");

        if (estado == 0)
            estado_bat.setText(R.string.bateria_correcta);
        else if(estado == 1)
            estado_bat.setText(R.string.bateria_caliente);
        else if(estado == 2)
            estado_bat.setText(R.string.bateria_fria);
        else if(estado == 3)
            estado_bat.setText(R.string.bateria_sobrecoltaje);
        else if(estado == 4)
            estado_bat.setText(R.string.bateria_desconocido);
        else if(estado == 5)
            estado_bat.setText(R.string.bateria_error);

        start = (ImageView)findViewById(R.id.start);

        start.setOnClickListener(new ImageButton.OnClickListener() {
            public void onClick(View v) {

                String recurso = "@drawable/start2";
                int imageResource = getResources().getIdentifier(recurso, null, getPackageName());
                Drawable imageSelect = getResources().getDrawable(imageResource);
                start.setImageDrawable(imageSelect);
                Toast.makeText(getApplicationContext(), R.string.start, Toast.LENGTH_LONG).show();


                start.setOnClickListener(new ImageButton.OnClickListener() {
                    public void onClick(View v) {
                        Toast.makeText(getApplicationContext(), R.string.encurso, Toast.LENGTH_SHORT).show();
                    }
                });

                        // ********************************

                // Delay interfaz
                new CountDownTimer(100, 100) {

                    public void onTick(long millisUntilFinished) {
                    }

                    public void onFinish() {
                        bechmarkStart();
                    }
                }.start();



                // ********************************

            }
        });
    }



    void bechmarkStart(){
        boolean wifi_conectado;
        boolean blu_inicio;;

        Calendar c = Calendar.getInstance();
        int seg = c.get(Calendar.SECOND);
        int min = c.get(Calendar.MINUTE);
        Vibrator v = (Vibrator) this.getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
        BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();





        // START ******************************************************************************************

        double nivel_inicio = getNivelActualR();
        double time_ini = System.nanoTime();

        // EVITAR ATENUAR PANTALLA
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "START");
        wl.acquire();



        // SENSORES ON

        // wifi
       WifiManager wifi = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);

        wifi_conectado = wifi.isWifiEnabled();
        if (!wifi_conectado)
            wifi.setWifiEnabled(true);

        // Bluetooth
        blu_inicio = bluetooth.isEnabled();
        if (!blu_inicio) {
            bluetooth.enable();
        }

        // Aceleraci�n 3d
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);



        // C�MPUTOS
        for (int i = seg; i < 10 + seg; i++){

            for (int z = 0; z < 30; z++)
                v.vibrate(1000);


            for(int j = min; j < 5000 + min; j++){


                httpRequest("192.168.215.78");
                bluetooth.startDiscovery();
                String locationProvider = LocationManager.NETWORK_PROVIDER;

                Thread hebra = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        double sum = 0;
                        Calendar c = Calendar.getInstance();
                        int seg = c.get(Calendar.SECOND);
                        int min = c.get(Calendar.MINUTE);

                        // Localizaci�n GPS
                        String locationProvider = LocationManager.NETWORK_PROVIDER;


                        // C�mputos
                        for(int x = seg; x < 10000 + seg; x++) {
                            seg = c.get(Calendar.SECOND);
                            sum *= (seg / Math.pow(min,2));
                        }
                    }
                });
                hebra.start();

            }
            //Brillo
            Settings.System.putInt(getApplicationContext().getContentResolver(),Settings.System.SCREEN_BRIGHTNESS_MODE, 0);

            if (i % 2 == 0) {
                Settings.System.putInt(getApplicationContext().getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);

                WindowManager.LayoutParams wm = getWindow().getAttributes();
                wm.screenBrightness = 255;
                getWindow().setAttributes(wm);
            }else{
                Settings.System.putInt(getApplicationContext().getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 0);

                WindowManager.LayoutParams wm = getWindow().getAttributes();
                wm.screenBrightness = 0;
                getWindow().setAttributes(wm);

            }


        }

        wl.release();


        // RESULTADOS **************************************************************
        double nivel_final = getNivelActualR();
        double time_fin = System.nanoTime();
        setResults(nivel_inicio, nivel_final, time_ini, time_fin);

        // Restaurar *****************************************************************
        if (!wifi_conectado)
            wifi.setWifiEnabled(false);


        if (!blu_inicio)
            bluetooth.disable();



    }


    void setResults(double nivel, double nivel_final, double time_ini, double time_fin){
        Toast.makeText(getApplicationContext(), R.string.correcto, Toast.LENGTH_SHORT).show();
        setContentView(R.layout.results);



        //*****

        double puntuacion = nivel - nivel_final;
        double sum = 100.0;


        for(int i = 1; i <= puntuacion; i++) {

            double valor = sum - i;
            valor = valor / 10.0;

            sum = sum - valor;
        }

        puntuacion = sum;


        DecimalFormat puntuacionF = new DecimalFormat("#0.###");
        String result = puntuacionF.format(puntuacion);
        //*******


        niveltext = (TextView) findViewById(R.id.niveltext);
        niveltext.setText(R.string.niveltext);

        nivel_result = (TextView) findViewById(R.id.nivel_result);
        nivel_result.setText(result);


        double time = (time_fin - time_ini)  / 1000000000.0;;

        time_result = (TextView) findViewById(R.id.timeresult);

        time_result.setText(Double.toString(time));

        double diferencia = (nivel_final - nivel) / getEscala()  * 100.0f;

        bateria_var = (TextView) findViewById(R.id.bateria_v);
        bateria_var.setText(Double.toString(diferencia));




    }


    void init(){
        actual = getNivelActual();
        temperatura = getTemperaturaActual();
        voltaje = getVoltaje();
        estado = getEstadoBateria();

        if (estaCargando()){
            Toast.makeText(getApplicationContext(), R.string.errorCargando, Toast.LENGTH_SHORT).show();
        }

        nivelactual = (TextView) findViewById(R.id.nivelactual);
        temperatura_nivel = (TextView) findViewById(R.id.temperatura_nivel);
        voltaje_act = (TextView) findViewById(R.id.voltaje_act);
        estado_bat = (TextView) findViewById(R.id.estado_bat);

    }


    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
        init();
    }



    private final BroadcastReceiver bluetoothre = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = (BluetoothDevice) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
            }
        }
    };


    public boolean estaCargando(){

        IntentFilter batteryIntent = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = getApplicationContext().registerReceiver(null, batteryIntent);

        int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);


        return  (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL);
    }



    public float getNivelActual() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int nivel = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int escala = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

        if(nivel == -1 || escala == -1) {
            return -1f;
        }

        return ((float)nivel / (float)escala) * 100.0f;
    }

    public double getNivelActualR() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        double nivel = (double)batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        Log.d("ANTES",Double.toString(nivel));
        String.format("%.4f", nivel);
        Log.d("DESPUES", Double.toString(nivel));
        return (nivel);
    }

    public double getEscala() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        double escala = (double)batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        return escala;
    }




    public float getTemperaturaActual(){
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int temperatura = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);
        return ((float) temperatura) / 10;

    }


    public float getVoltaje(){
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int voltaje = batteryIntent.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0);
        return ((float) voltaje) / 1000;

    }

    public int getEstadoBateria() {
        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        int estado =  batteryIntent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);

        if (estado ==  BatteryManager.BATTERY_HEALTH_GOOD)
            return 0; // Correcta

        if (estado == BatteryManager.BATTERY_HEALTH_OVERHEAT)
            return 1; //Sobrecalentada

        if (estado == BatteryManager.BATTERY_HEALTH_COLD)
            return 2; //fría

        if (estado == BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE)
            return 3; //sobrevoltaje

        if (estado == BatteryManager.BATTERY_HEALTH_UNKNOWN)
            return 4; //Desconocido

        if (estado == BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE)
            return 5; //Errores


        return -1;


    }


    public static void httpRequest(String url)
    {

        HttpClient httpclient = new DefaultHttpClient();
        HttpGet httpget = new HttpGet(url);

        HttpResponse response;
        try {
            response = httpclient.execute(httpget);

            HttpEntity entity = response.getEntity();

        } catch (Exception e) {}
    }


}
